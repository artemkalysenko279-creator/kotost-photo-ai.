import base64
import os
from io import BytesIO

import httpx
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="котость Фото ИИ API")

# The mobile client talks only to this backend. Never put the OpenAI key in the APK.
API_KEY = os.getenv("OPENAI_API_KEY")
IMAGE_MODEL = os.getenv("OPENAI_IMAGE_MODEL", "gpt-image-2")
MAX_BYTES = 12 * 1024 * 1024
ALLOWED = {"image/jpeg", "image/png", "image/webp"}

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restrict this to your own app/site if you add browser clients.
    allow_methods=["POST", "GET"],
    allow_headers=["*"],
)

@app.get("/health")
async def health():
    return {"ok": True, "service": "kotost-photo-ai"}

@app.post("/edit")
async def edit_image(prompt: str = Form(...), image: UploadFile = File(...)):
    if not API_KEY:
        raise HTTPException(status_code=503, detail="Сервер ещё не настроен: нет OPENAI_API_KEY.")
    if not prompt.strip() or len(prompt) > 2000:
        raise HTTPException(status_code=400, detail="Описание должно содержать от 1 до 2000 символов.")
    if image.content_type not in ALLOWED:
        raise HTTPException(status_code=415, detail="Поддерживаются JPG, PNG и WEBP.")
    raw = await image.read()
    if not raw or len(raw) > MAX_BYTES:
        raise HTTPException(status_code=413, detail="Фото пустое или больше 12 МБ.")

    # OpenAI Images Edit endpoint: POST /v1/images/edits
    data = {"model": IMAGE_MODEL, "prompt": prompt.strip(), "size": "auto", "quality": "medium"}
    files = {"image": (image.filename or "upload.jpg", BytesIO(raw), image.content_type)}
    try:
        async with httpx.AsyncClient(timeout=180.0) as client:
            response = await client.post(
                "https://api.openai.com/v1/images/edits",
                headers={"Authorization": f"Bearer {API_KEY}"},
                data=data,
                files=files,
            )
        if response.is_error:
            try:
                message = response.json().get("error", {}).get("message", "Ошибка сервиса генерации.")
            except Exception:
                message = "Ошибка сервиса генерации."
            raise HTTPException(status_code=502, detail=message[:500])
        result = response.json()
        encoded = result["data"][0]["b64_json"]
        return {"image_base64": encoded, "format": "png"}
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Обработка заняла слишком много времени. Попробуй ещё раз.")
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=502, detail="Не удалось связаться с сервисом генерации.")
