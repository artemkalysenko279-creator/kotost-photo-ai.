package ru.kotost.photoai

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit
import android.net.Uri
import android.util.Base64

private val Bg = Color(0xFF101114)
private val Panel = Color(0xFF1B1D22)
private val Accent = Color(0xFFB99CFF)
private val Muted = Color(0xFF9A9DA8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KotostApp() }
    }
}

private data class ChatItem(
    val prompt: String,
    val bitmap: Bitmap? = null,
    val error: String? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun KotostApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("kotost", 0) }
    var serverUrl by remember { mutableStateOf(prefs.getString("server", "http://10.0.2.2:8000/") ?: "") }
    var showSettings by remember { mutableStateOf(false) }
    var prompt by remember { mutableStateOf("") }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedBytes by remember { mutableStateOf<ByteArray?>(null) }\n    var selectedMime by remember { mutableStateOf("image/jpeg") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Выбери фото и напиши, что изменить") }
    val messages = remember { mutableStateListOf<ChatItem>() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedUri = uri
        selectedBytes = uri?.let {
            runCatching { context.contentResolver.openInputStream(it)?.use { stream -> stream.readBytes() } }.getOrNull()
        }
        status = if (selectedBytes != null) "Фото выбрано. Теперь опиши изменение." else "Не удалось открыть фото."
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Accent,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(containerColor = Bg) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(42.dp).background(Accent.copy(alpha = .18f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Text("🐈‍⬛", fontSize = 23.sp) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("котость Фото ИИ", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("редактор фотографий с ИИ", color = Muted, fontSize = 12.sp)
                    }
                    TextButton(onClick = { showSettings = !showSettings }) { Text("Настройки") }
                }

                if (showSettings) {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(12.dp)) {
                            Text("Адрес сервера", fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(6.dp))
                            OutlinedTextField(
                                value = serverUrl,
                                onValueChange = { serverUrl = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                placeholder = { Text("https://твой-сервер/") }
                            )
                            Text("Для эмулятора Android подходит http://10.0.2.2:8000/. Для телефона укажи HTTPS-адрес своего сервера.",
                                color = Muted, fontSize = 11.sp)
                            Button(onClick = {
                                prefs.edit().putString("server", serverUrl.trim()).apply()
                                showSettings = false
                            }) { Text("Сохранить") }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }

                if (messages.isEmpty()) {
                    Spacer(Modifier.height(34.dp))
                    Text("Что сделаем с фото?", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Загрузи изображение и напиши, как хочешь его изменить.",
                        color = Muted, fontSize = 14.sp)
                    Spacer(Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Suggestion("Сделай как в мультфильме") { prompt = it }
                        Suggestion("Замени фон на закат") { prompt = it }
                    }
                }

                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    items(messages) { item ->
                        Column(
                            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(12.dp)
                        ) {
                            Text(item.prompt, fontWeight = FontWeight.Medium)
                            Spacer(Modifier.height(8.dp))
                            if (item.bitmap != null) {
                                Image(
                                    bitmap = item.bitmap.asImageBitmap(),
                                    contentDescription = "Изменённое изображение",
                                    modifier = Modifier.fillMaxWidth().heightIn(max = 360.dp)
                                )
                                TextButton(onClick = { saveImage(context, item.bitmap) }) {
                                    Icon(Icons.Default.Download, null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("Сохранить фото")
                                }
                            }
                            if (item.error != null) Text(item.error, color = Color(0xFFFF9A9A))
                        }
                    }
                    if (busy) item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(color = Accent, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(10.dp))
                            Text("ИИ обрабатывает фото…", color = Muted)
                        }
                    }
                }

                if (selectedBytes != null) {
                    Text("✓ Фото выбрано", color = Accent, fontSize = 13.sp)
                }
                Text(status, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 14.dp),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = { picker.launch("image/*") },
                        modifier = Modifier.size(50.dp).background(Panel, CircleShape)
                    ) { Icon(Icons.Default.AddPhotoAlternate, "Выбрать фото", tint = Accent) }

                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Например: сделай фон космическим…") },
                        shape = RoundedCornerShape(22.dp),
                        maxLines = 4
                    )
                    IconButton(
                        onClick = {
                            val bytes = selectedBytes
                            val text = prompt.trim()
                            if (bytes == null) { status = "Сначала выбери фотографию."; return@IconButton }
                            if (text.isBlank()) { status = "Напиши, что нужно изменить."; return@IconButton }
                            if (busy) return@IconButton
                            busy = true
                            status = "Отправляем фото на обработку…"
                            messages.add(ChatItem(text))
                            prompt = ""
                            scope.launch {
                                try {
                                    val bitmap = withContext(Dispatchers.IO) {
                                        editPhoto(serverUrl, bytes, selectedMime, text)
                                    }
                                    messages.add(ChatItem("Готово: $text", bitmap = bitmap))
                                    selectedBytes = null
                                    selectedUri = null
                                    status = "Готово! Можешь выбрать следующее фото."
                                } catch (e: Exception) {
                                    messages.add(ChatItem("Не удалось обработать фото", error = e.message ?: "Проверь адрес сервера и подключение."))
                                    status = "Ошибка обработки."
                                } finally { busy = false }
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.size(50.dp).background(Accent, CircleShape)
                    ) { Icon(Icons.Default.Send, "Отправить", tint = Color(0xFF17121F)) }
                }
            }
        }
    }
}

@Composable
private fun Suggestion(label: String, onClick: (String) -> Unit) {
    Surface(
        onClick = { onClick(label) },
        color = Panel,
        shape = RoundedCornerShape(18.dp)
    ) { Text(label, modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp), color = Accent, fontSize = 12.sp) }
}

private fun editPhoto(server: String, bytes: ByteArray, mimeType: String, prompt: String): Bitmap {
    val base = server.trim().let { if (it.endsWith("/")) it else "$it/" }
    require(base.startsWith("https://") || base.startsWith("http://")) { "Укажи корректный адрес сервера в настройках." }
    val extension = when (mimeType) { "image/png" -> ".png"; "image/webp" -> ".webp"; else -> ".jpg" }\n    val file = File.createTempFile("kotost_upload", extension)
    file.writeBytes(bytes)
    try {
        val client = OkHttpClient.Builder()
            .callTimeout(180, TimeUnit.SECONDS)
            .connectTimeout(20, TimeUnit.SECONDS)
            .build()
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("prompt", prompt)
            .addFormDataPart("image", "photo$extension", file.asRequestBody(mimeType.toMediaType()))
            .build()
        val request = Request.Builder().url(base + "edit").post(body).build()
        client.newCall(request).execute().use { response ->
            val payload = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail = runCatching { JSONObject(payload).optString("detail") }.getOrNull()
                throw IllegalStateException(detail ?: "Сервер ответил кодом ${response.code}")
            }
            val encoded = JSONObject(payload).getString("image_base64")
            val result = Base64.decode(encoded, Base64.DEFAULT)
            return BitmapFactory.decodeByteArray(result, 0, result.size)
                ?: throw IllegalStateException("Сервер вернул неподдерживаемое изображение.")
        }
    } finally { file.delete() }
}

private fun saveImage(context: android.content.Context, bitmap: Bitmap) {
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "kotost_${System.currentTimeMillis()}.png")
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/KotostPhotoAI")
    }
    val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        ?: return
    context.contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
}
